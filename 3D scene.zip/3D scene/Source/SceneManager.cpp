///////////////////////////////////////////////////////////////////////////////
// scenemanager.cpp
// ================
// This file contains the implementation of the `SceneManager` class, which is 
// responsible for managing the preparation and rendering of 3D scenes. It 
// handles textures, materials, lighting configurations, and object rendering.
//
// AUTHOR: Brian Battersby
// INSTITUTION: Southern New Hampshire University (SNHU)
// COURSE: CS-330 Computational Graphics and Visualization
//
// INITIAL VERSION: November 1, 2023
// LAST REVISED: December 1, 2024
//
// RESPONSIBILITIES:
// - Load, bind, and manage textures in OpenGL.
// - Define materials and lighting properties for 3D objects.
// - Manage transformations and shader configurations.
// - Render complex 3D scenes using basic meshes.
//
// NOTE: This implementation leverages external libraries like `stb_image` for 
// texture loading and GLM for matrix and vector operations.
///////////////////////////////////////////////////////////////////////////////

//Roger Fisher 10/15/2025

#include "SceneManager.h"

#ifndef STB_IMAGE_IMPLEMENTATION
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#endif

#define GLM_ENABLE_EXPERIMENTAL
#include <glm/gtx/transform.hpp>

// declaration of global variables
namespace
{
	const char* g_ModelName = "model";
	const char* g_ColorValueName = "objectColor";
	const char* g_TextureValueName = "objectTexture";
	const char* g_UseTextureName = "bUseTexture";
	const char* g_UseLightingName = "bUseLighting";
}

/***********************************************************
 *  SceneManager()
 *
 *  The constructor for the class
 ***********************************************************/
SceneManager::SceneManager(ShaderManager *pShaderManager)
{
	m_pShaderManager = pShaderManager;
	m_basicMeshes = new ShapeMeshes();

	// initialize the texture collection
	for (int i = 0; i < 16; i++)
	{
		m_textureIDs[i].tag = "/0";
		m_textureIDs[i].ID = -1;
	}
	m_loadedTextures = 0;
}

/***********************************************************
 *  ~SceneManager()
 *
 *  The destructor for the class
 ***********************************************************/
SceneManager::~SceneManager()
{
	m_pShaderManager = NULL;
	delete m_basicMeshes;
	m_basicMeshes = NULL;
	// destroy the created OpenGL textures
	DestroyGLTextures();
}

/***********************************************************
 *  CreateGLTexture()
 *
 *  This method is used for loading textures from image files,
 *  configuring the texture mapping parameters in OpenGL,
 *  generating the mipmaps, and loading the read texture into
 *  the next available texture slot in memory.
 ***********************************************************/
bool SceneManager::CreateGLTexture(const char* filename, std::string tag)
{
	int width = 0;
	int height = 0;
	int colorChannels = 0;
	GLuint textureID = 0;

	// indicate to always flip images vertically when loaded
	stbi_set_flip_vertically_on_load(true);

	// try to parse the image data from the specified image file
	unsigned char* image = stbi_load(
		filename,
		&width,
		&height,
		&colorChannels,
		0);

	// if the image was successfully read from the image file
	if (image)
	{
		std::cout << "Successfully loaded image:" << filename << ", width:" << width << ", height:" << height << ", channels:" << colorChannels << std::endl;

		glGenTextures(1, &textureID);
		glBindTexture(GL_TEXTURE_2D, textureID);

		// set the texture wrapping parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
		// set texture filtering parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

		// if the loaded image is in RGB format
		if (colorChannels == 3)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB8, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
		// if the loaded image is in RGBA format - it supports transparency
		else if (colorChannels == 4)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);
		else
		{
			std::cout << "Not implemented to handle image with " << colorChannels << " channels" << std::endl;
			return false;
		}

		// generate the texture mipmaps for mapping textures to lower resolutions
		glGenerateMipmap(GL_TEXTURE_2D);

		// free the image data from local memory
		stbi_image_free(image);
		glBindTexture(GL_TEXTURE_2D, 0); // Unbind the texture

		// register the loaded texture and associate it with the special tag string
		m_textureIDs[m_loadedTextures].ID = textureID;
		m_textureIDs[m_loadedTextures].tag = tag;
		m_loadedTextures++;

		return true;
	}

	std::cout << "Could not load image:" << filename << std::endl;

	// Error loading the image
	return false;
}

/***********************************************************
 *  BindGLTextures()
 *
 *  This method is used for binding the loaded textures to
 *  OpenGL texture memory slots.  There are up to 16 slots.
 ***********************************************************/
void SceneManager::BindGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		// bind textures on corresponding texture units
		glActiveTexture(GL_TEXTURE0 + i);
		glBindTexture(GL_TEXTURE_2D, m_textureIDs[i].ID);
	}
}

/***********************************************************
 *  DestroyGLTextures()
 *
 *  This method is used for freeing the memory in all the
 *  used texture memory slots.
 ***********************************************************/
void SceneManager::DestroyGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		if (m_textureIDs[i].ID != 0)
			glDeleteTextures(1, &m_textureIDs[i].ID);
		m_textureIDs[i].ID = 0;
		m_textureIDs[i].tag = "/0";
	}
	m_loadedTextures = 0;
}

/***********************************************************
 *  FindTextureID()
 *
 *  This method is used for getting an ID for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureID(std::string tag)
{
	int textureID = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureID = m_textureIDs[index].ID;
			bFound = true;
		}
		else
			index++;
	}

	return(textureID);
}

/***********************************************************
 *  FindTextureSlot()
 *
 *  This method is used for getting a slot index for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureSlot(std::string tag)
{
	int textureSlot = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureSlot = index;
			bFound = true;
		}
		else
			index++;
	}

	return(textureSlot);
}

/***********************************************************
 *  FindMaterial()
 *
 *  This method is used for getting a material from the previously
 *  defined materials list that is associated with the passed in tag.
 ***********************************************************/
bool SceneManager::FindMaterial(std::string tag, OBJECT_MATERIAL& material)
{
	if (m_objectMaterials.size() == 0)
	{
		return(false);
	}

	int index = 0;
	bool bFound = false;
	while ((index < m_objectMaterials.size()) && (bFound == false))
	{
		if (m_objectMaterials[index].tag.compare(tag) == 0)
		{
			bFound = true;
			material.diffuseColor = m_objectMaterials[index].diffuseColor;
			material.specularColor = m_objectMaterials[index].specularColor;
			material.shininess = m_objectMaterials[index].shininess;
		}
		else
		{
			index++;
		}
	}

	return(true);
}

/***********************************************************
 *  SetTransformations()
 *
 *  This method is used for setting the transform buffer
 *  using the passed in transformation values.
 ***********************************************************/
void SceneManager::SetTransformations(
	glm::vec3 scaleXYZ,
	float XrotationDegrees,
	float YrotationDegrees,
	float ZrotationDegrees,
	glm::vec3 positionXYZ)
{
	// variables for this method
	glm::mat4 modelView;
	glm::mat4 scale;
	glm::mat4 rotationX;
	glm::mat4 rotationY;
	glm::mat4 rotationZ;
	glm::mat4 translation;

	// set the scale value in the transform buffer
	scale = glm::scale(scaleXYZ);
	// set the rotation values in the transform buffer
	rotationX = glm::rotate(glm::radians(XrotationDegrees), glm::vec3(1.0f, 0.0f, 0.0f));
	rotationY = glm::rotate(glm::radians(YrotationDegrees), glm::vec3(0.0f, 1.0f, 0.0f));
	rotationZ = glm::rotate(glm::radians(ZrotationDegrees), glm::vec3(0.0f, 0.0f, 1.0f));
	// set the translation value in the transform buffer
	translation = glm::translate(positionXYZ);

	modelView = translation * rotationZ * rotationY * rotationX * scale;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setMat4Value(g_ModelName, modelView);
	}
}

/***********************************************************
 *  SetShaderColor()
 *
 *  This method is used for setting the passed in color
 *  into the shader for the next draw command
 ***********************************************************/
void SceneManager::SetShaderColor(
	float redColorValue,
	float greenColorValue,
	float blueColorValue,
	float alphaValue)
{
	// variables for this method
	glm::vec4 currentColor;

	currentColor.r = redColorValue;
	currentColor.g = greenColorValue;
	currentColor.b = blueColorValue;
	currentColor.a = alphaValue;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, false);
		m_pShaderManager->setVec4Value(g_ColorValueName, currentColor);
	}
}

/***********************************************************
 *  SetShaderTexture()
 *
 *  This method is used for setting the texture data
 *  associated with the passed in ID into the shader.
 ***********************************************************/
void SceneManager::SetShaderTexture(
	std::string textureTag)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, true);

		int textureID = -1;
		textureID = FindTextureSlot(textureTag);
		m_pShaderManager->setSampler2DValue(g_TextureValueName, textureID);
	}
}

/***********************************************************
 *  SetTextureUVScale()
 *
 *  This method is used for setting the texture UV scale
 *  values into the shader.
 ***********************************************************/
void SceneManager::SetTextureUVScale(float u, float v)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setVec2Value("UVscale", glm::vec2(u, v));
	}
}

/***********************************************************
  *  LoadSceneTextures()
  *
  *  This method is used for preparing the 3D scene by loading
  *  the shapes, textures in memory to support the 3D scene
  *  rendering
  ***********************************************************/
void SceneManager::LoadSceneTextures()
{
	/*** STUDENTS - add the code BELOW for loading the textures that ***/
	/*** will be used for mapping to objects in the 3D scene. Up to  ***/
	/*** 16 textures can be loaded per scene. Refer to the code in   ***/
	/*** the OpenGL Sample for help.                                 ***/

	bool bReturn = false;

	CreateGLTexture("textures/paper.png", "paper"); //paper for the koala box

	CreateGLTexture("textures/koala.png", "koala"); //koala symbol!

	CreateGLTexture("textures/blackPlastic.png", "plastic"); //table texture

	CreateGLTexture("textures/Aluminum.png", "metal"); //Soda can texture

	CreateGLTexture("textures/SandArt.png", "sand"); //Sand art texture

	CreateGLTexture("textures/water.png", "water"); //water for the bottle

	CreateGLTexture("textures/candy1.png", "candy1"); //candy for the candy box

	CreateGLTexture("textures/candy2.png", "candy2"); //second candy box texure

	CreateGLTexture("textures/vitamin.png", "vitamin"); //fruit for the vitamin bottle

	CreateGLTexture("textures/cap.png", "cap"); //lid cap texture

	CreateGLTexture("textures/truffles.png", "truffle"); //truffle bag texture

	CreateGLTexture("textures/curtains.png", "curtains"); //background curtains


	// after the texture image data is loaded into memory, the
	// loaded textures need to be bound to texture slots - there
	// are a total of 16 available slots for scene textures
	BindGLTextures();
}

/***********************************************************
 *  SetShaderMaterial()
 *
 *  This method is used for passing the material values
 *  into the shader.
 ***********************************************************/
void SceneManager::SetShaderMaterial(std::string materialTag)
{
	if (m_objectMaterials.empty()) return;

	OBJECT_MATERIAL m;
	if (FindMaterial(materialTag, m))
	{
		m_pShaderManager->setVec3Value("material.ambientColor", m.ambientColor);
		m_pShaderManager->setFloatValue("material.ambientStrength", m.ambientStrength);
		m_pShaderManager->setVec3Value("material.diffuseColor", m.diffuseColor);
		m_pShaderManager->setVec3Value("material.specularColor", m.specularColor);
		m_pShaderManager->setFloatValue("material.shininess", m.shininess);
	}
}

/***********************************************************
 *  DefineObjectMaterials()
 *  Simple materials you can switch between before draws.
 ***********************************************************/
void SceneManager::DefineObjectMaterials()
{
	m_objectMaterials.clear();

	OBJECT_MATERIAL floorMat;
	floorMat.tag = "floor";
	floorMat.ambientColor = glm::vec3(0.15f, 0.15f, 0.15f);
	floorMat.ambientStrength = 0.25f;
	floorMat.diffuseColor = glm::vec3(0.25f, 0.25f, 0.25f); 
	floorMat.specularColor = glm::vec3(0.10f, 0.10f, 0.10f); //low reflection
	floorMat.shininess = 8.0f;
	m_objectMaterials.push_back(floorMat);

	//light glossy laminate for candy boxes
	OBJECT_MATERIAL GlossLam;
	GlossLam.tag = "glossLam";
	GlossLam.ambientColor = glm::vec3(0.2f, 0.2f, 0.2f);
	GlossLam.ambientStrength = 0.15f;
	GlossLam.diffuseColor = glm::vec3(0.60f, 0.60f, 0.65f); //slightly cool white
	GlossLam.specularColor = glm::vec3(0.9f);  //reflective sheen
	GlossLam.shininess = 32.0f; //make it tighter
	m_objectMaterials.push_back(GlossLam);

	//simple neutral white
	OBJECT_MATERIAL white;
	white.tag = "white";
	white.ambientColor = glm::vec3(0.20f);
	white.ambientStrength = 0.25f;
	white.diffuseColor = glm::vec3(1.0f);
	white.specularColor = glm::vec3(0.5f);
	white.shininess = 64.0f;
	m_objectMaterials.push_back(white);


	//material for soda can
	OBJECT_MATERIAL metalMat;
	metalMat.tag = "metal";
	metalMat.ambientColor = glm::vec3(0.4f, 0.4f, 0.4f);
	metalMat.ambientStrength = 0.2f;
	metalMat.diffuseColor = glm::vec3(0.8f, 0.8f, 0.8f);    //bright base
	metalMat.specularColor = glm::vec3(1.0f, 1.0f, 1.0f);   //strong white highlight
	metalMat.shininess = 48.0f;                             //very sharp reflections
	m_objectMaterials.push_back(metalMat);

	//material for glass display for candles
	OBJECT_MATERIAL glassMat;
	glassMat.tag = "glass";
	glassMat.ambientColor = glm::vec3(0.4f, 0.45f, 0.5f);   //slightly cool tint
	glassMat.ambientStrength = 0.1f;
	glassMat.diffuseColor = glm::vec3(0.7f, 0.8f, 0.9f);    //bright reflection tone
	glassMat.specularColor = glm::vec3(1.0f, 1.0f, 1.0f);
	glassMat.shininess = 96.0f;                             //very high gloss
	m_objectMaterials.push_back(glassMat);

	//material for truffle bag
	OBJECT_MATERIAL truffleBag;
	truffleBag.tag = "truffle";
	truffleBag.ambientColor = glm::vec3(0.25f, 0.22f, 0.18f);
	truffleBag.ambientStrength = 0.2f;
	truffleBag.diffuseColor = glm::vec3(0.6f, 0.45f, 0.35f); //brownish tone
	truffleBag.specularColor = glm::vec3(0.9f, 0.8f, 0.6f);  //gold-tinged highlights
	truffleBag.shininess = 48.0f;
	m_objectMaterials.push_back(truffleBag);
}

/***********************************************************
 *  SetupSceneLights()
 *  Two lights: blue key + neutral fill.
 ***********************************************************/
void SceneManager::SetupSceneLights()
{
	m_pShaderManager->setBoolValue("bUseLighting", true);

	//Soft skylight (enable your directional) 
	m_pShaderManager->setBoolValue("directionalLight.bActive", true);
	m_pShaderManager->setVec3Value("directionalLight.direction", -0.2f, -1.0f, -0.1f);
	m_pShaderManager->setVec3Value("directionalLight.ambient", 0.15f, 0.17f, 0.20f);
	m_pShaderManager->setVec3Value("directionalLight.diffuse", 0.3f, 0.35f, 0.45f);
	m_pShaderManager->setVec3Value("directionalLight.specular", 0.5f, 0.5f, 0.55f);

	//Blue curtain light (cool daylight from the back/right)
	m_pShaderManager->setBoolValue("pointLights[0].bActive", true);
	m_pShaderManager->setVec3Value("pointLights[0].position", 7.0f, 5.0f, -6.0f);  //behind/right of box
	m_pShaderManager->setVec3Value("pointLights[0].ambient", 0.05f, 0.07f, 0.1f);
	m_pShaderManager->setVec3Value("pointLights[0].diffuse", 0.4f, 0.5f, 0.9f);   //blue tint
	m_pShaderManager->setVec3Value("pointLights[0].specular", 0.5f, 0.6f, 1.0f);

	//Overhead lamp (warm light above left shoulder)
	m_pShaderManager->setBoolValue("pointLights[1].bActive", true);
	m_pShaderManager->setVec3Value("pointLights[1].position", -3.0f, 6.0f, 3.0f); //left of camera, above
	m_pShaderManager->setVec3Value("pointLights[1].ambient", 0.12f, 0.12f, 0.1f);
	m_pShaderManager->setVec3Value("pointLights[1].diffuse", 1.2f, 1.1f, 0.9f);  //warm yellowish tone
	m_pShaderManager->setVec3Value("pointLights[1].specular", 1.0f, 0.9f, 0.8f);

	//dim "glint" light near camera for subtle reflection on Koala box 
	m_pShaderManager->setBoolValue("pointLights[2].bActive", true);
	m_pShaderManager->setVec3Value("pointLights[2].position", 0.6f, 1.0f, 3.0f);
	m_pShaderManager->setVec3Value("pointLights[2].ambient", 0.05f, 0.05f, 0.05f);
	m_pShaderManager->setVec3Value("pointLights[2].diffuse", 0.4f, 0.4f, 0.4f);
	m_pShaderManager->setVec3Value("pointLights[2].specular", 0.4f, 0.4f, 0.4f);
}

/**************************************************************/
/*** STUDENTS CAN MODIFY the code in the methods BELOW for  ***/
/*** preparing and rendering their own 3D replicated scenes.***/
/*** Please refer to the code in the OpenGL sample project  ***/
/*** for assistance.                                        ***/
/**************************************************************/


/***********************************************************
 *  PrepareScene()
 *
 *  This method is used for preparing the 3D scene by loading
 *  the shapes, textures in memory to support the 3D scene 
 *  rendering
 ***********************************************************/
void SceneManager::PrepareScene()
{
	// load the textures for the 3D scene
	LoadSceneTextures();
		DefineObjectMaterials();   // predefine materials you�ll use
	SetupSceneLights();        // set positions/colors and enable lighting
	

	// only one instance of a particular mesh needs to be
	// loaded in memory no matter how many times it is drawn
	// in the rendered 3D scene

	m_basicMeshes->LoadPlaneMesh();
	m_basicMeshes->LoadBoxMesh();
	m_basicMeshes->LoadTaperedCylinderMesh();
	m_basicMeshes->LoadTorusMesh();
	m_basicMeshes->LoadSphereMesh();
	m_basicMeshes->LoadCylinderMesh();
	m_basicMeshes->LoadConeMesh();
	m_basicMeshes->LoadPrismMesh();

}

/***********************************************************
 *  RenderScene()
 *
 *  This method is used for rendering the 3D scene by 
 *  transforming and drawing the basic 3D shapes
 ***********************************************************/
void SceneManager::RenderScene()
{
	m_pShaderManager->setBoolValue("bUseLighting", true); //lighting
	SetShaderMaterial("white");

	//--------------Bottom plane, Table------------
	//Table plane establishes the ground and anchors all the objects

	// declare the variables for the transformations
	glm::vec3 scaleXYZ;
	float XrotationDegrees = 0.0f;
	float YrotationDegrees = 0.0f;
	float ZrotationDegrees = 0.0f;
	glm::vec3 positionXYZ;

	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(30.0f, 1.75f, 30.0f); //expanded the table plane so its easier to navigate the camera

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(0.0f, 0.0f, 0.0f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	m_pShaderManager->setBoolValue("useOverlay", false); //no need to layer here
	SetShaderMaterial("floor"); //for the material light reflections
	SetShaderTexture("plastic");

	// draw the mesh with transformation values
	m_basicMeshes->DrawPlaneMesh();
	

	/****************************************************************/

		//--------------Back Planes, Simple Curtain------------

	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA); //enabling the ability for transparency

	//---Backdrop
	scaleXYZ = glm::vec3(50.0f, 1.0f, 50.0f); //Make it large so it fills the background

	// set the XYZ rotation for the mesh
	XrotationDegrees = 90.0f; //Make it stand
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(0.0f, -10.0f, -20.0f); //Keep it behind everything

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	m_pShaderManager->setBoolValue("useOverlay", false); //no layering here
	SetShaderTexture("curtains"); 

	// draw the mesh with transformation values
	m_basicMeshes->DrawPlaneMesh();


	//---right side
	scaleXYZ = glm::vec3(50.0f, 1.0f, 50.0f); //Make it large so it fills the background

	// set the XYZ rotation for the mesh
	XrotationDegrees = 90.0f; //Make it stand
	YrotationDegrees = 90.0f; //turn the plane so it fills the side
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(30.0f, -10.0f, -20.0f); //Keep it behind everything

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	m_pShaderManager->setBoolValue("useOverlay", false); //no layering here
	SetShaderTexture("curtains"); 

	// draw the mesh with transformation values
	m_basicMeshes->DrawPlaneMesh();

	//---left side
	scaleXYZ = glm::vec3(50.0f, 1.0f, 50.0f); //Make it large so it fills the background

	// set the XYZ rotation for the mesh
	XrotationDegrees = 90.0f; //Make it stand
	YrotationDegrees = 90.0f; //turned to the side so it fills the side view
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(-30.0f, -10.0f, -20.0f); //Keep it behind everything

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	m_pShaderManager->setBoolValue("useOverlay", false); //no layering here
	SetShaderTexture("curtains"); 

	// draw the mesh with transformation values
	m_basicMeshes->DrawPlaneMesh();

	//---behind curtain
	scaleXYZ = glm::vec3(50.0f, 1.0f, 50.0f); //Make it large so it fills the background

	// set the XYZ rotation for the mesh
	XrotationDegrees = 90.0f; //Make it stand
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(20.0f, -10.0f, 30.0f); //Keep it behind everything

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	m_pShaderManager->setBoolValue("useOverlay", false); //no layering here
	SetShaderTexture("curtains"); 

	// draw the mesh with transformation values
	m_basicMeshes->DrawPlaneMesh();

	/****************************************************************/

				//--------------Koala Box------------

	////--------------Prism 1 (Koala Box)------------
// Koala hex box is built from 6 identical prisms at 60� intervals.
// The koala sticker is now layered directly onto the prism surface.

	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(1.2991f, 5.25f, 2.25f); //Using inches for object measurements where I can. Also slightly widened X to close seams between prisms

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 00.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(-4.0f, 2.625f, -3.5f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderMaterial("glossLam"); //proper lighting for the material
	SetTextureUVScale(1.0f, 1.0f);

	
	// assign layered textures (paper base + koala overlay)
	m_pShaderManager->setSampler2DValue("baseTexture", FindTextureSlot("paper"));
	m_pShaderManager->setSampler2DValue("overlayTexture", FindTextureSlot("koala"));
	m_pShaderManager->setBoolValue("useOverlay", true);

	// add per-prism UV offset (shift image up a bit if needed)
	m_pShaderManager->setVec2Value("overlayOffset", glm::vec2(0.0f, 0.0f));  // X, Y offset

	// draw the prism with both textures applied
	m_basicMeshes->DrawPrismMesh();



	/****************************************************************/

	//--------------Prism 2 (Koala Box)------------

	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(1.2991f, 5.25f, 2.25f); //Using inches for object measurements where I can. Also slightly widened X to close seams between prisms

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 60.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(-4.0f, 2.625f, -3.5f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderMaterial("glossLam"); //proper lighting for the material
	SetTextureUVScale(1.0f, 1.0f);

	// assign layered textures (paper base + koala overlay)
	m_pShaderManager->setSampler2DValue("baseTexture", FindTextureSlot("paper"));
	m_pShaderManager->setSampler2DValue("overlayTexture", FindTextureSlot("koala"));
	m_pShaderManager->setBoolValue("useOverlay", true);

	// add per-prism UV offset (shift image up a bit)
	m_pShaderManager->setVec2Value("overlayOffset", glm::vec2(0.0f, 0.0f));  // X, Y offset

	// draw the prism with both textures applied
	m_basicMeshes->DrawPrismMesh();

	

	/****************************************************************/

	//--------------Prism 3 (Koala Box)------------

	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(1.2991f, 5.25f, 2.25f); //Using inches for object measurements where I can. Also slightly widened X to close seams between prisms

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 120.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(-4.0f, 2.625f, -3.5f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderMaterial("glossLam"); //proper lighting for the material
	SetTextureUVScale(1.0f, 1.0f);

	// assign layered textures (paper base + koala overlay)
	m_pShaderManager->setSampler2DValue("baseTexture", FindTextureSlot("paper"));
	m_pShaderManager->setSampler2DValue("overlayTexture", FindTextureSlot("koala"));
	m_pShaderManager->setBoolValue("useOverlay", true);

	// add per-prism UV offset (shift image up a bit)
	m_pShaderManager->setVec2Value("overlayOffset", glm::vec2(0.0f, 0.0f));  // X, Y offset

	// draw the prism with both textures applied
	m_basicMeshes->DrawPrismMesh();
	
	/****************************************************************/

	//--------------Prism 4 (Koala Box)------------

	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(1.2991f, 5.25f, 2.25f); //Using inches for object measurements where I can. Also slightly widened X to close seams between prisms

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 180.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(-4.0f, 2.625f, -3.5f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderMaterial("glossLam"); //proper lighting for the material
	SetTextureUVScale(1.0f, 1.0f);

	// assign layered textures (paper base + koala overlay)
	m_pShaderManager->setSampler2DValue("baseTexture", FindTextureSlot("paper"));
	m_pShaderManager->setSampler2DValue("overlayTexture", FindTextureSlot("koala"));
	m_pShaderManager->setBoolValue("useOverlay", true);

	// add per-prism UV offset (shift image up a bit)
	m_pShaderManager->setVec2Value("overlayOffset", glm::vec2(0.0f, 0.0f));  // X, Y offset

	// draw the prism with both textures applied
	m_basicMeshes->DrawPrismMesh();

	
	/****************************************************************/

	//--------------Prism 5 (Koala Box)------------

	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(1.2991f, 5.25f, 2.25f); //Using inches for object measurements where I can. Also slightly widened X to close seams between prisms

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 240.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(-4.0f, 2.625f, -3.5f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderMaterial("glossLam"); //proper lighting for the material
	SetTextureUVScale(1.0f, 1.0f);

	// assign layered textures (paper base + koala overlay)
	m_pShaderManager->setSampler2DValue("baseTexture", FindTextureSlot("paper"));
	m_pShaderManager->setSampler2DValue("overlayTexture", FindTextureSlot("koala"));
	m_pShaderManager->setBoolValue("useOverlay", true);

	// add per-prism UV offset (shift image up a bit)
	m_pShaderManager->setVec2Value("overlayOffset", glm::vec2(0.0f, 0.0f));  // X, Y offset

	// draw the prism with both textures applied
	m_basicMeshes->DrawPrismMesh();

	/****************************************************************/

	//--------------Prism 6 (Koala Box)------------
	
	//Koala hex box is built from 6 identical prisms at 60 degree intervals

	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(1.2991f, 5.25f, 2.25f); //Using inches for object measurements where I can. Also slightly widened X to close seams between prisms

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 300.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(-4.0f, 2.625f, -3.5f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderMaterial("glossLam"); //proper lighting for the material
	SetTextureUVScale(1.0f, 1.0f);

	// assign layered textures (paper base + koala overlay)
	m_pShaderManager->setSampler2DValue("baseTexture", FindTextureSlot("paper"));
	m_pShaderManager->setSampler2DValue("overlayTexture", FindTextureSlot("koala"));
	m_pShaderManager->setBoolValue("useOverlay", true);

	// add per-prism UV offset (shift image up a bit)
	m_pShaderManager->setVec2Value("overlayOffset", glm::vec2(0.0f, 0.0f));  // X, Y offset

	// draw the prism with both textures applied
	m_basicMeshes->DrawPrismMesh();

	/****************************************************************/

		//--------------Cylinder candle 1---------------------
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(1.875f, 3.5f, 1.875f);   // diameter, height
	
	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(-0.9f, 0.0f, -4.4f);

	
	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);


	SetShaderMaterial("glass"); //proper lighting for the material
	SetTextureUVScale(1.0f, 1.0f);
	m_pShaderManager->setBoolValue("useOverlay", false); //no layering here
	SetShaderColor(1.0f, 0.95f, 0.7f, 1.0f); //good color for the candle
	m_basicMeshes->DrawCylinderMesh();

	//----Lid
	scaleXYZ = glm::vec3(2.0f, 0.25f, 2.0f);
	
	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(-0.9f, 3.5f, -4.4f);  // sits just above

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);
	
	m_pShaderManager->setBoolValue("useOverlay", false); //no layering
	SetShaderColor(0.05f, 0.05f, 0.05f, 1.0f);
	m_basicMeshes->DrawCylinderMesh();

	//--------------Cylinder candle 2---------------------
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(1.875f, 3.5f, 1.875f);   // diameter, height

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(3.1f, 0.0f, -5.0f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderMaterial("glass"); //proper lighting for the material
	SetTextureUVScale(1.0f, 1.0f);
	m_pShaderManager->setBoolValue("useOverlay", false); //no layering
	SetShaderColor(1.0f, 0.95f, 0.7f, 1.0f); //good color for the candle
	m_basicMeshes->DrawCylinderMesh();

	//----Lid
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(2.0f, 0.25f, 2.0f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(3.1f, 3.5f, -5.0f);  // sits just above

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	m_pShaderManager->setBoolValue("useOverlay", false); //no layering
	SetShaderColor(0.05f, 0.05f, 0.05f, 1.0f);
	m_basicMeshes->DrawCylinderMesh();

	//--------------Cylinder candle 3---------------------
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(1.875f, 3.5f, 1.875f);   // diameter, height

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(1.0f, 3.75f, -4.7f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderMaterial("glass"); //proper lighting for the material
	SetTextureUVScale(1.0f, 1.0f);
	m_pShaderManager->setBoolValue("useOverlay", false); //no layering
	SetShaderColor(1.0f, 0.95f, 0.7f, 1.0f);
	m_basicMeshes->DrawCylinderMesh();

	//----Lid
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(2.0f, 0.25f, 2.0f);
	
	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;
	
	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(1.0f, 7.25f, -4.7f);  // sits just above

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	m_pShaderManager->setBoolValue("useOverlay", false); //no layering
	SetShaderColor(0.05f, 0.05f, 0.05f, 1.0f);
	m_basicMeshes->DrawCylinderMesh();

		//--------------Cylinder soda can---------------------
	//----main body
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(1.25f, 3.75f, 1.25f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(6.5f, 0.3f, 1.0f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderMaterial("metal"); //proper lighting for the material
	SetTextureUVScale(1.0f, 1.0f);
	m_pShaderManager->setBoolValue("useOverlay", false); //no layering
	SetShaderTexture("metal");
	m_basicMeshes->DrawCylinderMesh();

	// ----Top Lip (slightly narrower + thinner)
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(1.15f, 0.3f, 1.15f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(6.5f, 4.05f, 1.0f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderMaterial("metal"); //proper lighting for the material
	SetTextureUVScale(1.0f, 1.0f);
	m_pShaderManager->setBoolValue("useOverlay", false); //no layering
	SetShaderTexture("metal");
	m_basicMeshes->DrawCylinderMesh();

	//-----Bottom piece
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(1.18f, 0.3f, 1.18f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(6.5f, 0.0f, 1.0f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderMaterial("metal"); //proper lighting for the material
	SetTextureUVScale(1.0f, 1.0f);
	m_pShaderManager->setBoolValue("useOverlay", false); //no layering
	SetShaderTexture("metal");
	m_basicMeshes->DrawCylinderMesh();

		//--------------Cylinder water bottle-----------------
	
	//---Main body
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(1.0f, 5.0f, 1.0f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(6.0f, 0.0f, -1.5f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	m_pShaderManager->setBoolValue("useOverlay", false); //no layering
	SetShaderTexture("water");
	m_basicMeshes->DrawCylinderMesh();


	//----curvature of the bottle top
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(1.0f, 2.0f, 1.0f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(6.0f, 5.0f, -1.5f); //sits above the main body

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	m_pShaderManager->setBoolValue("useOverlay", false); //no layering
	SetShaderColor(0.8f, 0.9f, 1.0f, 0.3f); //make it transparent 
	m_basicMeshes->DrawTaperedCylinderMesh();


	//----cap
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(0.5f, 0.5f, 0.5f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(6.0f, 7.0f, -1.5f); //sits above the curvature

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	m_pShaderManager->setBoolValue("useOverlay", false); //no layering
	SetShaderTexture("cap");
	m_basicMeshes->DrawCylinderMesh();

		//--------------Vitamin bottle------------------------
		
	//----Main body
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(2.5f, 4.0f, 2.0f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 90.0f;  //lay the bottle down
	YrotationDegrees = 300.0f; //appropriate angling on the table
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(-8.1f, 1.0f, 3.9f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	m_pShaderManager->setBoolValue("useOverlay", false); //no layering
	SetShaderTexture("vitamin");
	m_basicMeshes->DrawBoxMesh();

	//----curvature bottle top part

	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(1.15f, 0.75f, 1.0f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 270.0f; //lay it down
	YrotationDegrees = 300.0f; //angle it right 
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(-6.35f, 1.0f, 2.90f); //on top of the main body

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	m_pShaderManager->setBoolValue("useOverlay", false); //no layering
	SetShaderColor(0.7f, 0.9f, 1.0f, 0.35f); //make it a bit clear like an actual bottle
	m_basicMeshes->DrawTaperedCylinderMesh();


	//-----cap of the vitamin bottle
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(0.75f, 0.5f, 0.75f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 270.0f; //lay it down
	YrotationDegrees = 300.0f; //position it correctly
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(-6.0f, 1.0f, 2.7f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	m_pShaderManager->setBoolValue("useOverlay", false); //no layering
	SetShaderTexture("cap");
	m_basicMeshes->DrawCylinderMesh();

		//--------------Candy box (reese's pieces)------------
		// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(2.5f, 6.0f, 0.5f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 90.0f; //positioning it correctly

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(-4.4f, 1.25f, -2.0f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderMaterial("glossLam"); //proper lighting for the material
	SetTextureUVScale(1.0f, 1.0f);
	m_pShaderManager->setBoolValue("useOverlay", false); //no layering
	SetShaderTexture("candy1"); 
	m_basicMeshes->DrawBoxMesh();

		//--------------Pocky Box-----------------------------
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(3.5f, 6.5f, 0.75f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 10.0f;
	YrotationDegrees = 90.0f; //gotta lean it properly 
	ZrotationDegrees = 325.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(-7.86f, 2.6f, -3.5f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderMaterial("glossLam"); //proper lighting for the material
	SetTextureUVScale(1.0f, 1.0f);
	m_pShaderManager->setBoolValue("useOverlay", false); //no layering
	SetShaderTexture("candy2");
	m_basicMeshes->DrawBoxMesh();

		//--------------Bag of truffles-----------------------
		// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(8.5f, 1.5f, 4.0f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 95.0f; //lay it down on the table
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(3.2f, 0.75f, 2.0f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);
	
	SetShaderMaterial("truffle"); //proper lighting for the material
	SetTextureUVScale(1.0f, 1.0f);
	m_pShaderManager->setBoolValue("useOverlay", false); //no layering
	SetShaderTexture("truffle");
	m_basicMeshes->DrawBoxMesh();

	//---Inner empty area (white insert)
	scaleXYZ = glm::vec3(0.5f, 1.498, 3.999f);  // slightly smaller so it fits inside
	XrotationDegrees = 0.0f;
	YrotationDegrees = 95.0f;
	ZrotationDegrees = 0.0f;

	// move it slightly up and forward into the bag
	positionXYZ = glm::vec3(3.549f, 0.75f, 5.99f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// set it to solid white
	m_pShaderManager->setBoolValue("useOverlay", false); //no layering
	SetShaderColor(0.9f, 0.9f, 0.9f, 1.0f); //make it white like the inside of the bag

	m_basicMeshes->DrawBoxMesh();

		//--------------Truffles Fallen out of Bag------------
	// --- truffle 1
	scaleXYZ = glm::vec3(0.5f, 0.5, 0.5f);
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// move it slightly up and forward into the bag
	positionXYZ = glm::vec3(3.5f, 0.5f, 7.5f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// set it to solid white
	m_pShaderManager->setBoolValue("useOverlay", false); //no layering
	SetShaderColor(0.44f, 0.21f, 0.0f, 1.0f); //chocolate color

	m_basicMeshes->DrawSphereMesh();

	// --- truffle 2
	scaleXYZ = glm::vec3(0.5f, 0.5, 0.5f);
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// move it slightly up and forward into the bag
	positionXYZ = glm::vec3(2.5f, 0.5f, 6.85f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// set it to solid white
	m_pShaderManager->setBoolValue("useOverlay", false); //no layering
	SetShaderColor(0.44f, 0.21f, 0.0f, 1.0f); //chocolate color

	m_basicMeshes->DrawSphereMesh();

	// --- truffle 3
	scaleXYZ = glm::vec3(0.5f, 0.5, 0.5f);
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// move it slightly up and forward into the bag
	positionXYZ = glm::vec3(4.5f, 0.5f, 6.25f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// set it to solid white
	m_pShaderManager->setBoolValue("useOverlay", false); //no layering
	SetShaderColor(0.44f, 0.21f, 0.0f, 1.0f); //chocolate color

	m_basicMeshes->DrawSphereMesh();

	//--------------Sand display--------------------------
	
	//-----Base
	scaleXYZ = glm::vec3(9.5f, 2.0, 1.5f);  
	XrotationDegrees = 0.0f;
	YrotationDegrees = -15.0f; //angle it properly
	ZrotationDegrees = 0.0f;

	// move it slightly up and forward into the bag
	positionXYZ = glm::vec3(12.0f, 1.0f, -6.0f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	m_pShaderManager->setBoolValue("useOverlay", false); //no layering
	SetShaderColor(0.1f, 0.1f, 0.1f, 1.0f); //make it black

	m_basicMeshes->DrawBoxMesh();

	//--- Ring
	scaleXYZ = glm::vec3(6.0f, 0.3, 5.0f);
	XrotationDegrees = 90.0f;
	YrotationDegrees = -15.0f; //all about the angling of the cylinder
	ZrotationDegrees = 0.0f;

	// move it slightly up and forward into the bag
	positionXYZ = glm::vec3(12.0f, 5.5f, -6.009f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	m_pShaderManager->setBoolValue("useOverlay", false); //no layering
	SetShaderColor(0.05f, 0.05f, 0.05f, 1.0f); //darkly colored

	m_basicMeshes->DrawCylinderMesh();

	//--- Inner hole
	scaleXYZ = glm::vec3(5.3f, 0.31, 4.4f);
	XrotationDegrees = 90.0f;
	YrotationDegrees = -15.0f;
	ZrotationDegrees = 0.0f;


	positionXYZ = glm::vec3(12.0f, 5.5f, -6.01f); //center into the ring so it appears like the sand display

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);


	SetShaderMaterial("glass"); //proper lighting for the material
	SetTextureUVScale(1.0f, 1.0f);
	m_pShaderManager->setBoolValue("useOverlay", false); //no layering
	SetShaderTexture("sand");

	m_basicMeshes->DrawCylinderMesh();

}
